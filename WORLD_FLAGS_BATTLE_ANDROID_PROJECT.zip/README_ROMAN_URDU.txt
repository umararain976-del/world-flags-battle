WORLD FLAGS BATTLE - ANDROID APK PROJECT

Maine tumhari game ko Android app project mein daal diya hai.
APK banane ke liye free GitHub Actions workflow bhi included hai.

APK banane ka asaan tareeqa:
1. github.com par free account banao / login karo.
2. New repository banao. Naam: world-flags-battle
3. Is ZIP ko extract karo.
4. Extracted project ke tamam folders/files GitHub repository mein upload karo.
5. Upload ke baad repository mein Actions tab kholo.
6. "Build Android APK" workflow select karke "Run workflow" dabao.
7. Build complete hone par workflow run kholo.
8. Neeche Artifacts mein WORLD-FLAGS-BATTLE-APK download karo.
9. ZIP extract karo. app-debug.apk par tap karke install karo.

Note:
- Yeh debug APK hai, personal testing/install ke liye.
- Pehli dafa Android "Install unknown apps" permission maang sakta hai.
- APK banane ke liye GitHub account aur internet zaroori hain.
- Game ka HTML offline app ke andar included hai.
